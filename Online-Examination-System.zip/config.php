
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "examflow"; 

// $host = 'localhost';
// $db   = 'examflow';
// $user = 'root';
// $pass = '';
// $charset = 'utf8mb4';



// $servername = "sql211.infinityfree.com";
// $username = "if0_38639085"; 
// $password = "examflow2005"; 
// $dbname = "if0_38639085_examflow"; 


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>

