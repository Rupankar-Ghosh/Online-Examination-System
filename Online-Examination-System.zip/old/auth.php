
<?php
    function generateUniqueId($department, $tableName, $mysql)
    {
        $year = date("Y");
        $month = date("m");
        $day = date("d");

        $sql = "SELECT COUNT(*) AS total FROM $tableName";
        $result = mysqli_query($mysql, $sql);
        $row = mysqli_fetch_assoc($result);
        $totalCount = $row['total'] + 1;

        $uniqueId = $department . $year . $month . $day . $totalCount;
        return $uniqueId;
    }

    $mysql = mysqli_connect("localhost", "root", "", "minor_project");

    if ($mysql === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }

    if (isset($_POST["submit"])) {
        $password = $_POST['password'];
        $name = $_POST['name'];
        $gender = $_POST['gender'];
        $dob = $_POST['dob'];
        $qualification = $_POST['qualification'];
        $specialization = $_POST['specialization'];
        $experience = $_POST['experience'];
        $contact_no = $_POST['contact_no'];
        $email = $_POST['email'];
        $aadhar_no = $_POST['aadhar_no'];
        $address = $_POST['address'];

        $tableName = "teachers";
        $newId = generateUniqueId("T", $tableName, $mysql);

        $sql = "INSERT INTO teachers VALUES ('$newId', '$password', '$name', '$gender', '$dob', '$qualification', '$specialization', '$experience', '$contact_no', '$email', '$aadhar_no', '$address')";

        if (mysqli_query($mysql, $sql)) {
            echo "<script>alert('Teacher added successfully' + '\\n\\n' + 'Name: $name' +'\\n' + 'Generated ID: $newId');  window.location.href = 'admin.php';</script>";
        } else {
            echo "ERROR: Could not execute $sql. " . mysqli_error($mysql);
        }
    }

    mysqli_close($mysql);
    ?>



<?php
// PHP Section
session_start();

// Database configuration (example)
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'examflow';

// Handle form submission
$error = '';
$email = isset($_POST['email']) ? $_POST['email'] : (isset($_SESSION['verify_email']) ? $_SESSION['verify_email'] : 'rg111login@gmail.com');
$verification_code = isset($_POST['verification_code']) ? $_POST['verification_code'] : '';

// Simulate verification (in a real app, you'd check against database)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    if (empty($verification_code)) {
        $error = 'Please enter the verification code';
    } elseif ($verification_code !== '123456') { // Hardcoded for demo
        $error = 'Invalid verification code. Please try again.';
    } else {
        // Verification successful - redirect to dashboard
        $_SESSION['verified'] = true;
        header('Location: dashboard.php');
        exit();
    }
}

// Handle resend code
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend'])) {
    // In a real app, you would generate and send a new code
    $error = 'A new verification code has been sent to your email.';
    $_SESSION['verify_email'] = $email;
}

// Handle email change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_email'])) {
    $email = '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ExamFlow - Verify Email</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Preloader Styles */
        #preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.5s ease;
        }
        
        .loader {
            width: 48px;
            height: 48px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #4a6bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            position: relative;
        }
        
        .loader::after {
            content: '';
            position: absolute;
            top: -8px;
            left: -8px;
            right: -8px;
            bottom: -8px;
            border: 5px solid transparent;
            border-top-color: #4a6bff;
            border-radius: 50%;
            animation: spin 1.5s linear infinite;
            opacity: 0.7;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .loaded #preloader {
            opacity: 0;
            pointer-events: none;
        }
        
        /* Main Styles */
        :root {
            --primary-color: #4a6bff;
            --secondary-color: #3a5bef;
            --error-color: #ff4a4a;
            --text-color: #333;
            --light-text: #666;
            --lighter-text: #e0e0e0;
            --bg-color: #f5f5f5;
            --card-bg: #ffffff;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
            background-color: var(--bg-color);
            color: var(--text-color);
            flex-direction: row-reverse;
        }
        
        .left-section {
            width: 50%;
            background-color: var(--card-bg);
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .right-section {
            width: 50%;
            background: linear-gradient(135deg, var(--primary-color), #6a4aff);
            color: white;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        .right-section::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .right-section::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -30px;
            width: 250px;
            height: 250px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 30px;
            color: var(--primary-color);
            display: flex;
            align-items: center;
        }
        
        .logo i {
            margin-right: 10px;
            color: var(--primary-color);
        }
        
        .error-message {
            color: var(--error-color);
            margin-bottom: 20px;
            font-size: 14px;
            padding: 10px 15px;
            background-color: rgba(255, 74, 74, 0.1);
            border-radius: 5px;
            display: <?php echo !empty($error) ? 'block' : 'none'; ?>;
        }
        
        .verification-box {
            width: 100%;
            max-width: 450px;
            background-color: var(--card-bg);
            padding: 40px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        
        .verification-box:hover {
            transform: translateY(-5px);
        }
        
        .verification-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
        }
        
        h1 {
            font-size: 26px;
            margin-bottom: 20px;
            color: var(--text-color);
        }
        
        h2 {
            font-size: 16px;
            margin-bottom: 15px;
            color: var(--light-text);
            font-weight: normal;
            line-height: 1.6;
        }
        
        .email-address {
            font-weight: bold;
            color: var(--text-color);
        }
        
        .timer {
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
        }
        
        .timer i {
            margin-right: 8px;
        }
        
        .input-group {
            position: relative;
            margin-bottom: 25px;
        }
        
        .input-group input {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .input-group input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(74, 107, 255, 0.2);
            outline: none;
        }
        
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--light-text);
        }
        
        .verify-button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-bottom: 20px;
            transition: all 0.3s;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .verify-button i {
            margin-left: 8px;
        }
        
        .verify-button:hover {
            background: linear-gradient(to right, var(--secondary-color), var(--primary-color));
            box-shadow: 0 5px 15px rgba(74, 107, 255, 0.4);
        }
        
        .action-links {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        .action-link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
            transition: all 0.2s;
            display: flex;
            align-items: center;
        }
        
        .action-link i {
            margin-right: 5px;
        }
        
        .action-link:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }
        
        .welcome-title {
            font-size: 32px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }
        
        .feature {
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
            padding-left: 40px;
        }
        
        .feature i {
            position: absolute;
            left: 0;
            top: 5px;
            font-size: 20px;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .feature h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: white;
        }
        
        .feature p {
            color: var(--lighter-text);
            line-height: 1.6;
            font-size: 15px;
        }
        
        /* Responsive styles */
        @media (max-width: 992px) {
            body {
                flex-direction: column;
            }
            
            .left-section, .right-section {
                width: 100%;
                padding: 30px;
            }
            
            .right-section {
                padding-bottom: 50px;
            }
            
            .left-section {
                padding-top: 50px;
            }
            
            .verification-box {
                max-width: 500px;
            }
        }
        
        @media (max-width: 576px) {
            .left-section, .right-section {
                padding: 20px;
            }
            
            .verification-box {
                padding: 30px 20px;
            }
            
            .welcome-title {
                font-size: 28px;
            }
            
            .action-links {
                flex-direction: column;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>

    <!-- Email Verification Section -->
    <div class="left-section">
        <div class="logo"><i class="fas fa-graduation-cap"></i> ExamFlow</div>
        
        <div class="error-message" id="errorMessage"><?php echo htmlspecialchars($error); ?></div>
        
        <form method="POST" class="verification-box">
            <h1>Verify Your Email</h1>
            <h2>We've sent a 6-digit verification code to <span class="email-address"><?php echo htmlspecialchars($email); ?></span>. Please enter it below.</h2>
            
            <div class="input-group">
                <i class="fas fa-key"></i>
                <input type="text" name="verification_code" placeholder="Enter verification code" maxlength="6" pattern="\d{6}" title="Please enter a 6-digit code" required>
            </div>
            
            <div class="timer">
                <i class="fas fa-clock"></i> Code expires in: <span id="countdown">04:49</span>
            </div>
            
            <button type="submit" name="verify" class="verify-button">
                Verify <i class="fas fa-arrow-right"></i>
            </button>
            
            <div class="action-links">
                <a href="#" class="action-link" id="resendLink">
                    <i class="fas fa-redo"></i> Resend Code (<span id="resendTimer">00:19</span>)
                </a>
                <button type="submit" name="change_email" class="action-link" style="background: none; border: none; cursor: pointer;">
                    <i class="fas fa-envelope"></i> Change Email
                </button>
            </div>
        </form>
    </div>

    <!-- Welcome Section -->
    <div class="right-section">
        <div class="welcome-title">Welcome to ExamFlow</div>
        <p style="margin-bottom: 40px; color: var(--lighter-text);">Join thousands of educators and students using ExamFlow to simplify the examination process.</p>
        
        <div class="feature">
            <i class="fas fa-shield-alt"></i>
            <h3>Secure Testing Environment</h3>
            <p>Our platform ensures academic integrity with advanced security features including browser lockdown, AI proctoring, and plagiarism detection.</p>
        </div>
        
        <div class="feature">
            <i class="fas fa-chart-line"></i>
            <h3>Detailed Analytics</h3>
            <p>Get comprehensive insights into student performance with detailed reports, question-level analysis, and comparative statistics.</p>
        </div>
        
        <div class="feature">
            <i class="fas fa-clock"></i>
            <h3>Save Time</h3>
            <p>Automated grading, question banks, and powerful exam creation tools save hours of administrative work each week.</p>
        </div>
        
        <div class="feature">
            <i class="fas fa-mobile-alt"></i>
            <h3>Mobile Friendly</h3>
            <p>Students can take exams from any device with our fully responsive platform that works on smartphones, tablets, and computers.</p>
        </div>
    </div>

    <script>
        // Preloader JavaScript
        window.addEventListener('load', function() {
            // Add loaded class to body after page is fully loaded
            document.body.classList.add('loaded');
            
            // Remove preloader after animation completes
            setTimeout(function() {
                document.getElementById('preloader').style.display = 'none';
            }, 500);
        });

        // JavaScript for countdown timers
        document.addEventListener('DOMContentLoaded', function() {
            // Main verification code countdown
            let countdownTime = 4 * 60 + 49; // 4 minutes 49 seconds
            const countdownElement = document.getElementById('countdown');
            
            const countdownInterval = setInterval(function() {
                const minutes = Math.floor(countdownTime / 60);
                const seconds = countdownTime % 60;
                
                countdownElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                
                if (countdownTime <= 0) {
                    clearInterval(countdownInterval);
                    countdownElement.textContent = "Expired";
                    countdownElement.style.color = "var(--error-color)";
                } else {
                    countdownTime--;
                }
            }, 1000);
            
            // Resend code countdown
            let resendTime = 19; // 19 seconds
            const resendTimerElement = document.getElementById('resendTimer');
            const resendLink = document.getElementById('resendLink');
            
            const resendInterval = setInterval(function() {
                resendTimerElement.textContent = `00:${resendTime.toString().padStart(2, '0')}`;
                
                if (resendTime <= 0) {
                    clearInterval(resendInterval);
                    resendTimerElement.textContent = "Ready";
                    resendLink.href = "javascript:void(0)";
                    resendLink.onclick = function() {
                        document.querySelector('form').innerHTML += '<input type="hidden" name="resend" value="1">';
                        document.querySelector('form').submit();
                    };
                } else {
                    resendTime--;
                }
            }, 1000);
            
            // Input validation
            const verificationInput = document.querySelector('input[name="verification_code"]');
            verificationInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, ''); // Only allow numbers
                if (this.value.length > 6) {
                    this.value = this.value.slice(0, 6);
                }
            });
            
            // Error message handling
            const errorMessage = document.getElementById('errorMessage');
            if (errorMessage.textContent.trim() !== '') {
                errorMessage.style.display = 'block';
                setTimeout(() => {
                    errorMessage.style.opacity = '1';
                }, 100);
            }
        });
    </script>
</body>
</html>