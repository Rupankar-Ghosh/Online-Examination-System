<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Ensure this script is only accessed via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Only POST requests are allowed']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['email']) || !isset($data['otp'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Email and OTP are required']);
    exit;
}

$recipientEmail = $data['email'];
$otpCode = $data['otp'];

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->SMTPDebug = 0;                       // Debug mode: 0 = off, 1 = client messages, 2 = client and server messages
    $mail->isSMTP();                            // Use SMTP
    $mail->Host       = 'smtp.gmail.com';       // SMTP server
    $mail->SMTPAuth   = true;                   // Enable SMTP authentication
    $mail->Username   = 'rupankarghosh2012@gmail.com'; // Will be populated from secure environment variable
    $mail->Password   = 'zdqqrycmasqkjsak'; // Will be populated from secure environment variable
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS
    $mail->Port       = 587;                    // TCP port to connect to

    // Load credentials from environment variables or configuration file
    // In a production environment, use secure methods to store credentials
    $mail->Username = getenv('MAIL_USERNAME') ?: 'rupankarghosh2012@gmail.com';
    $mail->Password = getenv('MAIL_PASSWORD') ?: 'zdqqrycmasqkjsak';
    
    // Verify that we have credentials
    if (empty($mail->Username) || empty($mail->Password)) {
        throw new Exception('Email credentials are not configured. Please contact the administrator.');
    }

    // Recipients
    $mail->setFrom('noreply@examflow.com', 'ExamFlow');
    $mail->addAddress($recipientEmail);     // Add a recipient

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Your ExamFlow Verification Code';
    
    // Create a nice HTML email with the OTP code
    $mail->Body = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
            }
            .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
            }
            .header {
                background-color: #4a6cf7;
                color: white;
                padding: 20px;
                text-align: center;
            }
            .content {
                padding: 20px;
                background-color: #f9f9f9;
            }
            .otp-code {
                font-size: 28px;
                font-weight: bold;
                letter-spacing: 5px;
                text-align: center;
                margin: 30px 0;
                color: #333;
                padding: 10px;
                background-color: #e9e9e9;
                border-radius: 5px;
            }
            .footer {
                text-align: center;
                margin-top: 30px;
                font-size: 12px;
                color: #999;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>ExamFlow</h1>
            </div>
            <div class="content">
                <h2>Verification Code</h2>
                <p>Hello,</p>
                <p>Your verification code for ExamFlow is:</p>
                <div class="otp-code">' . $otpCode . '</div>
                <p>This code will expire in 5 minutes.</p>
                <p><strong>Important:</strong> If you did not request this code, please ignore this email.</p>
                <p>Thank you,<br>The ExamFlow Team</p>
            </div>
            <div class="footer">
                <p>&copy; ' . date('Y') . ' ExamFlow. All rights reserved.</p>
                <p>This is an automated message, please do not reply to this email.</p>
            </div>
        </div>
    </body>
    </html>';
    
    // Plain text alternative for email clients that don't support HTML
    $mail->AltBody = "Your ExamFlow verification code is: $otpCode\n\nThis code will expire in 5 minutes.";

    // Send the email
    $mail->send();
    
    // Return success response
    echo json_encode(['success' => true, 'message' => 'Verification code sent successfully']);
} catch (Exception $e) {
    // Log error (in a production environment)
    error_log("Email sending failed: {$mail->ErrorInfo}");
    
    // Return error response
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Could not send verification email', 'details' => $mail->ErrorInfo]);
}