<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join as Teacher | ExamFlow</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a6bff;
            --secondary-color: #3a5bef;
            --accent-color: #ff6b6b;
            --dark-color: #1a237e;
            --light-color: #f8fafc;
            --text-color: #2d3748;
            --light-text: #718096;
            --success-color: #4caf50;
            --warning-color: #ff9800;
            --error-color: #f44336;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            --shadow-hover: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        /* Preloader */
        #preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--light-color);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.5s ease;
        }

        .loader {
            width: 60px;
            height: 60px;
            position: relative;
        }

        .loader-circle {
            position: absolute;
            width: 100%;
            height: 100%;
            border: 4px solid transparent;
            border-top-color: var(--primary-color);
            border-radius: 50%;
            animation: spin 1.2s linear infinite;
        }

        .loader-circle:nth-child(2) {
            border-top-color: var(--accent-color);
            animation-delay: -0.4s;
            width: 80%;
            height: 80%;
            top: 10%;
            left: 10%;
        }

        .loader-circle:nth-child(3) {
            border-top-color: var(--secondary-color);
            animation-delay: -0.8s;
            width: 60%;
            height: 60%;
            top: 20%;
            left: 20%;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: var(--light-color);
            color: var(--text-color);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            position: relative;
        }

        section {
            padding: 80px 0;
            position: relative;
        }

        h1, h2, h3, h4 {
            font-weight: 600;
            line-height: 1.3;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        ul {
            list-style: none;
        }

        img {
            max-width: 100%;
            height: auto;
            display: block;
        }

        /* Buttons */
        .btn {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
            transition: var(--transition);
            cursor: pointer;
            border: none;
            position: relative;
            overflow: hidden;
        }

        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            color: white;
            box-shadow: 0 4px 15px rgba(74, 107, 255, 0.3);
            z-index: 1;
        }

        .btn-primary:hover {
            box-shadow: 0 8px 25px rgba(74, 107, 255, 0.4);
        }

        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
            z-index: -1;
        }

        .btn-primary:hover::before {
            left: 100%;
        }

        .btn-secondary {
            background: white;
            color: var(--primary-color);
            border: 1px solid var(--primary-color);
        }

        .btn-secondary:hover {
            background: var(--primary-color);
            color: white;
            box-shadow: 0 4px 15px rgba(74, 107, 255, 0.3);
        }

        /* Header */
        header {
            background-color: white;
            box-shadow: var(--shadow);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 100;
            transition: var(--transition);
        }

        header.scrolled {
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
        }

        .logo span {
            color: var(--primary-color);
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
        }

        .desktop-menu {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .desktop-menu li a {
            transition: var(--transition);
            font-weight: 500;
        }

        .mobile-menu-button {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }

        /* Teacher Registration Section */
        .teacher-registration {
            padding-top: 120px;
            background: linear-gradient(135deg, rgba(74, 107, 255, 0.05) 0%, rgba(74, 107, 255, 0) 100%);
            min-height: 100vh;
        }

        .registration-container {
            display: flex;
            align-items: flex-start;
            gap: 50px;
        }

        .registration-info {
            flex: 1;
            position: sticky;
            top: 120px;
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: var(--shadow);
            max-width: 400px;
        }

        .registration-info h2 {
            font-size: 28px;
            margin-bottom: 20px;
            color: var(--dark-color);
            position: relative;
        }

        .registration-info h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(to right, var(--primary-color), var(--accent-color));
            border-radius: 2px;
        }

        .registration-info p {
            color: var(--light-text);
            margin-bottom: 25px;
        }

        .benefits-list {
            margin-bottom: 30px;
        }

        .benefit-item {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            align-items: flex-start;
        }

        .benefit-icon {
            width: 24px;
            height: 24px;
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            flex-shrink: 0;
        }

        .benefit-text h4 {
            font-size: 16px;
            margin-bottom: 5px;
            color: var(--dark-color);
        }

        .benefit-text p {
            font-size: 14px;
            margin-bottom: 0;
            color: var(--light-text);
        }

        .registration-form-container {
            flex: 2;
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: var(--shadow);
        }

        .form-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .form-header h1 {
            font-size: 32px;
            color: var(--dark-color);
            margin-bottom: 10px;
        }

        .form-header p {
            color: var(--light-text);
        }

        .form-header .steps {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .step-indicator {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            background: #e2e8f0;
            color: var(--light-text);
            transition: var(--transition);
        }

        .step-indicator.active {
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            color: white;
        }

        .step-indicator.completed {
            background: var(--success-color);
            color: white;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 16px;
            transition: var(--transition);
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(74, 107, 255, 0.2);
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .form-group-full {
            grid-column: span 2;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            grid-column: span 2;
        }

        .password-strength {
            margin-top: 8px;
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
        }

        .strength-meter {
            height: 100%;
            width: 0;
            transition: width 0.3s ease;
        }

        .strength-weak {
            background-color: var(--error-color);
            width: 33%;
        }

        .strength-medium {
            background-color: var(--warning-color);
            width: 66%;
        }

        .strength-strong {
            background-color: var(--success-color);
            width: 100%;
        }

        .password-hint {
            font-size: 12px;
            color: var(--light-text);
            margin-top: 5px;
        }

        .form-note {
            font-size: 14px;
            color: var(--light-text);
            margin-top: 10px;
        }

        .form-note a {
            color: var(--primary-color);
            font-weight: 500;
        }

        /* Success Message */
        .success-message {
            text-align: center;
            padding: 40px;
        }

        .success-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(45deg, var(--success-color), #43a047);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            margin: 0 auto 20px;
        }

        .success-message h2 {
            font-size: 28px;
            margin-bottom: 15px;
            color: var(--success-color);
        }

        .success-message p {
            color: var(--light-text);
            margin-bottom: 25px;
        }

        .teacher-id {
            background: rgba(74, 107, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            font-size: 18px;
            font-weight: 600;
            color: var(--primary-color);
            text-align: center;
        }

        /* Responsive Styles */
        @media (max-width: 1024px) {
            .registration-container {
                flex-direction: column;
            }

            .registration-info {
                max-width: 100%;
                position: static;
            }
        }

        @media (max-width: 768px) {
            .desktop-menu {
                display: none;
            }

            .mobile-menu-button {
                display: block;
            }

            .teacher-registration {
                padding-top: 100px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group-full {
                grid-column: span 1;
            }
        }

        @media (max-width: 480px) {
            .registration-info,
            .registration-form-container {
                padding: 25px;
            }

            .form-header h1 {
                font-size: 28px;
            }

            .form-actions {
                flex-direction: column;
                gap: 15px;
            }

            .btn {
                width: 100%;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-in {
            animation: fadeIn 0.6s ease forwards;
        }

        .delay-1 { animation-delay: 0.1s; }
        .delay-2 { animation-delay: 0.2s; }
        .delay-3 { animation-delay: 0.3s; }
        .delay-4 { animation-delay: 0.4s; }
        .delay-5 { animation-delay: 0.5s; }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader">
            <div class="loader-circle"></div>
            <div class="loader-circle"></div>
            <div class="loader-circle"></div>
        </div>
    </div>

    <!-- Header -->
    <header id="header">
        <div class="container">
            <nav>
                <div class="logo">
                    <a href="index.php">Exam<span>Flow</span></a>
                </div>
                <ul class="desktop-menu">
                    <li><a href="index.php#features">Features</a></li>
                    <li><a href="index.php#how-it-works">How It Works</a></li>
                    <li><a href="index.php#testimonials">Testimonials</a></li>
                    <li><a href="login.html" class="btn btn-secondary">Log In</a></li>
                </ul>
                <div class="mobile-menu-button">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <!-- Teacher Registration Section -->
    <section class="teacher-registration">
        <div class="container">
            <div class="registration-container">
                <!-- Registration Info Panel -->
                <div class="registration-info animate-in delay-1">
                    <h2>Join as an Educator</h2>
                    <p>Create your teacher account to start building and managing exams with ExamFlow's powerful platform.</p>
                    
                    <div class="benefits-list">
                        <div class="benefit-item">
                            <div class="benefit-icon">
                                <i class="fas fa-pen"></i>
                            </div>
                            <div class="benefit-text">
                                <h4>Create Unlimited Exams</h4>
                                <p>Design custom exams with various question types and multimedia support.</p>
                            </div>
                        </div>
                        
                        <div class="benefit-item">
                            <div class="benefit-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <div class="benefit-text">
                                <h4>Advanced Analytics</h4>
                                <p>Get detailed insights into student performance and class trends.</p>
                            </div>
                        </div>
                        
                        <div class="benefit-item">
                            <div class="benefit-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="benefit-text">
                                <h4>Manage Classes</h4>
                                <p>Organize students into classes and track their progress over time.</p>
                            </div>
                        </div>
                        
                        <div class="benefit-item">
                            <div class="benefit-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="benefit-text">
                                <h4>Secure Platform</h4>
                                <p>Anti-cheating features and secure exam delivery for fair assessments.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-note">
                        Already have an account? <a href="login.html">Sign in here</a>
                    </div>
                </div>
                
                <!-- Registration Form -->
                <div class="registration-form-container animate-in delay-2">
                    <?php
                    function generateUniqueId($department, $tableName, $mysql) {
                        $year = date("Y");
                        $month = date("m");
                        $day = date("d");

                        $sql = "SELECT COUNT(*) AS total FROM $tableName";
                        $result = mysqli_query($mysql, $sql);
                        $row = mysqli_fetch_assoc($result);
                        $totalCount = $row['total'] + 1;

                        $uniqueId = $department . $year . $month . $day . $totalCount;
                        return $uniqueId;
                    }

                    $mysql = mysqli_connect("localhost", "root", "", "minor_project");

                    if ($mysql === false) {
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }

                    if (isset($_POST["submit"])) {
                        $password = $_POST['password'];
                        $name = $_POST['name'];
                        $gender = $_POST['gender'];
                        $dob = $_POST['dob'];
                        $qualification = $_POST['qualification'];
                        $specialization = $_POST['specialization'];
                        $experience = $_POST['experience'];
                        $contact_no = $_POST['contact_no'];
                        $email = $_POST['email'];
                        $aadhar_no = $_POST['aadhar_no'];
                        $address = $_POST['address'];

                        $tableName = "teachers"; 
                        $newId = generateUniqueId("T", $tableName, $mysql);

                        $sql = "INSERT INTO teachers VALUES ('$newId', '$password', '$name', '$gender', '$dob', '$qualification', '$specialization', '$experience', '$contact_no', '$email', '$aadhar_no', '$address')";

                        if (mysqli_query($mysql, $sql)) {
                            echo '<div class="success-message">
                                    <div class="success-icon">
                                        <i class="fas fa-check"></i>
                                    </div>
                                    <h2>Registration Successful!</h2>
                                    <p>Your teacher account has been created successfully. You can now log in to your account.</p>
                                    <div class="teacher-id">Your Teacher ID: ' . $newId . '</div>
                                    <a href="login.html" class="btn btn-primary">Go to Login</a>
                                </div>';
                        } else {
                            echo '<div class="form-group-full">
                                    <div style="background: rgba(244, 67, 54, 0.1); padding: 15px; border-radius: 8px; color: var(--error-color);">
                                        <i class="fas fa-exclamation-circle"></i> ERROR: Could not execute the query. ' . mysqli_error($mysql) . '
                                    </div>
                                </div>';
                        }
                        mysqli_close($mysql);
                    } else {
                    ?>
                    <div class="form-header">
                        <h1>Teacher Registration</h1>
                        <p>Fill in your details to create your teacher account</p>
                        <div class="steps">
                            <div class="step-indicator active">1</div>
                            <div class="step-indicator">2</div>
                            <div class="step-indicator">3</div>
                        </div>
                    </div>
                    
                    <form action="" method="POST" id="teacherForm">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="name">Full Name</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" required oninput="checkPasswordStrength(this.value)">
                                <div class="password-strength">
                                    <div class="strength-meter" id="passwordStrength"></div>
                                </div>
                                <div class="password-hint">Use at least 8 characters with a mix of letters, numbers & symbols</div>
                            </div>
                            
                            <div class="form-group">
                                <label for="contact_no">Contact Number</label>
                                <input type="tel" id="contact_no" name="contact_no" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select id="gender" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                    <option value="Prefer not to say">Prefer not to say</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="dob">Date of Birth</label>
                                <input type="date" id="dob" name="dob" required>
                            </div>
                            
                            <div class="form-group-full">
                                <h3 style="margin-bottom: 20px; color: var(--dark-color);">Professional Information</h3>
                            </div>
                            
                            <div class="form-group">
                                <label for="qualification">Highest Qualification</label>
                                <select id="qualification" name="qualification" required>
                                    <option value="">Select Qualification</option>
                                    <option value="PhD">PhD</option>
                                    <option value="Master's Degree">Master's Degree</option>
                                    <option value="Bachelor's Degree">Bachelor's Degree</option>
                                    <option value="Diploma">Diploma</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="specialization">Specialization</label>
                                <input type="text" id="specialization" name="specialization" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="experience">Years of Experience</label>
                                <input type="number" id="experience" name="experience" min="0" max="50" required>
                            </div>
                            
                            <div class="form-group-full">
                                <h3 style="margin-bottom: 20px; color: var(--dark-color);">Additional Information</h3>
                            </div>
                            
                            <div class="form-group">
                                <label for="aadhar_no">Aadhar Card Number</label>
                                <input type="text" id="aadhar_no" name="aadhar_no" required>
                            </div>
                            
                            <div class="form-group-full">
                                <label for="address">Address</label>
                                <textarea id="address" name="address" rows="4" required></textarea>
                            </div>
                            
                            <div class="form-group-full">
                                <div class="checkbox-group">
                                    <input type="checkbox" id="terms" required>
                                    <label for="terms">I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <a href="index.php" class="btn btn-secondary">Back to Home</a>
                                <button type="submit" name="submit" class="btn btn-primary">Complete Registration</button>
                            </div>
                        </div>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </section>

    <script>
        // Preloader
        window.addEventListener('load', function() {
            setTimeout(function() {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(function() {
                    document.getElementById('preloader').style.display = 'none';
                }, 500);
            }, 1000);
        });

        // Header scroll effect
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                document.getElementById('header').classList.add('scrolled');
            } else {
                document.getElementById('header').classList.remove('scrolled');
            }
        });

        // Password strength checker
        function checkPasswordStrength(password) {
            const strengthBar = document.getElementById('passwordStrength');
            let strength = 0;
            
            // Reset classes
            strengthBar.className = 'strength-meter';
            
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
            if (password.match(/\d/)) strength++;
            if (password.match(/[^a-zA-Z\d]/)) strength++;
            
            if (password.length === 0) {
                strengthBar.style.width = '0';
            } else if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
            } else if (strength === 3) {
                strengthBar.classList.add('strength-medium');
            } else {
                strengthBar.classList.add('strength-strong');
            }
        }

        // Form validation
        document.getElementById('teacherForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const terms = document.getElementById('terms').checked;
            
            if (password.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long');
                return;
            }
            
            if (!terms) {
                e.preventDefault();
                alert('You must agree to the Terms of Service and Privacy Policy');
                return;
            }
        });

        // Date picker max date (must be 18+ years old)
        const today = new Date();
        const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
        document.getElementById('dob').max = maxDate.toISOString().split('T')[0];

        // Animation on scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.animate-in');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.2;
                
                if (elementPosition < screenPosition) {
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }
            });
        }

        // Set initial state for animated elements
        document.querySelectorAll('.animate-in').forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });

        // Run animation check on load and scroll
        window.addEventListener('load', animateOnScroll);
        window.addEventListener('scroll', animateOnScroll);
    </script>
</body>
</html>