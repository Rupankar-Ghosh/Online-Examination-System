<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$mail = new PHPMailer(true);

$name="RG";
$otp="438745";

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';  // Your SMTP server (Gmail, Outlook, etc.)
    $mail->SMTPAuth   = true;
    $mail->Username   = 'rupankarghosh2012@gmail.com'; // Your email
    $mail->Password   = 'zdqqrycmasqkjsak'; // Your email password or App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
    $mail->Port       = 587;  // Port (587 for TLS, 465 for SSL)
    
    // **Disable TLS verification (Fix for SSL errors)**
    $mail->SMTPAutoTLS = false;
    $mail->isHTML(true);
    $mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );

    // Sender and Recipient
    $mail->setFrom('rupankarghosh2012@gmail.com', 'Your Name');
    $mail->addAddress('rg111login@gmail.com', 'Recipient Name');

    // Email Content
    $mail->Subject = 'Test Email using PHPMailer';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';

    // Send Email
    $mail->send();
    echo ' Email sent successfully!';
} catch (Exception $e) {
    echo " Email could not be sent. Error: {$mail->ErrorInfo}";
}
?>
